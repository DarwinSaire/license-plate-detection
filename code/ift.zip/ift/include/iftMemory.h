//
// Created by Alan Peixinho on 8/8/15.
//

#ifndef IFT_IFTMEMORY_H
#define IFT_IFTMEMORY_H

#include <stddef.h>

size_t iftMemoryUsed();

#endif //IFT_IFTMEMORY_H
