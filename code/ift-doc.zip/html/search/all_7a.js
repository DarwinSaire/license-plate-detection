var searchData=
[
  ['zsize',['zsize',['../d5/dec/structiftImage.html#a044215d2c7df412a81fedd913216e719',1,'iftImage']]]
];
