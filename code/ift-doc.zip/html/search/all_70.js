var searchData=
[
  ['pathname',['pathname',['../da/d6b/structiftFile.html#a0b20d4c2600fdebd4697f7edff49eee4',1,'iftFile']]]
];
