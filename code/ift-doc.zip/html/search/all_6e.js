var searchData=
[
  ['n',['n',['../d5/dec/structiftImage.html#a7aeea55b5b8596a61e1260829124b0e8',1,'iftImage']]],
  ['nfiles',['nfiles',['../d6/d6b/structiftDir.html#a637b96baaa2b46d7566981f33bdf4ab5',1,'iftDir']]],
  ['niters',['niters',['../da/d11/structiftMSPS.html#a864164297b4113adbc00fe8550e931a5',1,'iftMSPS']]],
  ['nsubdirs',['nsubdirs',['../d6/d6b/structiftDir.html#a8a4eb9532c1babb2cfbc174f97360ad9',1,'iftDir']]]
];
