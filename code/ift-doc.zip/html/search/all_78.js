var searchData=
[
  ['xsize',['xsize',['../d5/dec/structiftImage.html#a0bbd7827516731bf81910e5e46904cb6',1,'iftImage']]]
];
